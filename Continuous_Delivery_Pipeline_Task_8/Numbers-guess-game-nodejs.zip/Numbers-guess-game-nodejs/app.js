const express = require('express');
const app = express();
const port = 8080;

app.use(express.static('public'));
app.use(express.json());

let randomNumber = generateRandomNumber(); // Initial random number

app.get('/', (req, res) => {
  res.sendFile(__dirname + '/public/index.html');
});

app.post('/guess', (req, res) => {
  const userGuess = req.body.guess;

  if (!userGuess || isNaN(userGuess)) {
    return res.status(400).json({ message: 'Please provide a valid number.' });
  }

  if (userGuess < randomNumber) {
    res.json({ message: 'Too low! Try again.', success: false });
  } else if (userGuess > randomNumber) {
    res.json({ message: 'Too high! Try again.', success: false });
  } else {
    // User guessed the number correctly
    res.json({ message: 'Congratulations! You guessed the number!\nGenerating new number..', success: true });
    setTimeout(() => {
      randomNumber = generateRandomNumber(); // Generate new random number
    }, 2000); // Restart game after 2 seconds
  }
});

function generateRandomNumber() {
  return Math.floor(Math.random() * 10) + 1; // Random number between 1 and 10
}

app.listen(port, () => {
  console.log(`Game running at http://localhost:${port}`);
});
