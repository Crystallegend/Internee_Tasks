from flask import Flask, render_template
from ec2.ec2_manager import ec2_bp
from s3.s3_manager import s3_bp
from lambdaF.lambda_manager import lambda_bp
from linode.linode_manager import linode_bp
from storage.storage_manager import storage_bp
from aws_monitor.aws_manager import aws_bp
from linode_monitor.linodes_manager import linodes_bp

app = Flask(__name__)


# Register blueprints
app.register_blueprint(ec2_bp)
app.register_blueprint(s3_bp)
app.register_blueprint(lambda_bp)
app.register_blueprint(linode_bp)
app.register_blueprint(storage_bp)
app.register_blueprint(aws_bp)
app.register_blueprint(linodes_bp)

@app.route('/')
def index():
    return render_template('index.html')

if __name__ == '__main__':
    app.run()
