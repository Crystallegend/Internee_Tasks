from flask import Blueprint, jsonify, request, render_template
import boto3
from botocore.exceptions import ClientError
from config import AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, AWS_REGION

ec2_bp = Blueprint('ec2_bp', __name__)

# Initialize boto3 client
ec2 = boto3.client(
    'ec2',
    aws_access_key_id=AWS_ACCESS_KEY_ID,
    aws_secret_access_key=AWS_SECRET_ACCESS_KEY,
    region_name=AWS_REGION
)

@ec2_bp.route('/ec2', methods=['GET'])
def ec2_manager():
    # Fetch current running instances
    instances = ec2.describe_instances(Filters=[
        {'Name': 'instance-state-name', 'Values': ['pending', 'running', 'shutting-down', 'stopping', 'stopped', 'rebooting']}
    ])
    instance_data = []
    for reservation in instances['Reservations']:
        for instance in reservation['Instances']:
            instance_tags = {tag['Key']: tag['Value'] for tag in instance.get('Tags', [])}
            instance_data.append({
                'InstanceId': instance['InstanceId'],
                'InstanceType': instance['InstanceType'],
                'State': instance['State']['Name'],
                'Tags': instance_tags
            })
    return render_template('ec2.html', instances=instance_data)

@ec2_bp.route('/ec2/launch', methods=['POST'])
def launch_instance():
    instance_name = request.json.get('instance_name', 'MyInstance')
    response = ec2.run_instances(
        LaunchTemplate={'LaunchTemplateName': 't2-free'},
        MaxCount=1,
        MinCount=1,
        TagSpecifications=[{
            'ResourceType': 'instance',
            'Tags': [{'Key': 'Name', 'Value': instance_name}]
        }]
    )
    return jsonify({'message': 'Instance launch initiated.'}), 200

@ec2_bp.route('/ec2/<instance_id>/stop', methods=['POST'])
def stop_instance(instance_id):
    ec2.stop_instances(InstanceIds=[instance_id])
    return jsonify({'message': 'Instance stopped successfully'})

@ec2_bp.route('/ec2/<instance_id>/start', methods=['POST'])
def start_instance(instance_id):
    ec2.start_instances(InstanceIds=[instance_id])
    return jsonify({'message': 'Instance started successfully'})

@ec2_bp.route('/ec2/<instance_id>/terminate', methods=['POST'])
def terminate_instance(instance_id):
    ec2.terminate_instances(InstanceIds=[instance_id])
    return jsonify({'message': 'Instance terminated successfully'})

@ec2_bp.route('/ec2/<instance_id>/restart', methods=['POST'])
def restart_instance(instance_id):
    ec2.reboot_instances(InstanceIds=[instance_id])
    return jsonify({'message': 'Instance restarted successfully'})

def get_ec2_instances():
    try:
        response = ec2.describe_instances(Filters=[
            {'Name': 'instance-state-name', 'Values': ['pending', 'running', 'shutting-down', 'stopping', 'stopped', 'rebooting']}
        ])
        instance_data = []
        for reservation in response['Reservations']:
            for instance in reservation['Instances']:
                for tag in instance.get('Tags', []):
                    instance_tags = {tag['Key']: tag['Value']}
                instance_data.append({
                    'InstanceId': instance['InstanceId'],
                    'InstanceType': instance['InstanceType'],
                    'State': instance['State']['Name'],
                    'Tags': instance_tags
                })
        return instance_data
    except ClientError as e:
        print(f"Failed to describe EC2 instances: {str(e)}")
        return []