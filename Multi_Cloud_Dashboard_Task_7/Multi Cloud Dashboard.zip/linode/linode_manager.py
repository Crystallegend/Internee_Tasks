from flask import Blueprint, jsonify, request, render_template
from linode_api4 import LinodeClient
from config import LINODE_API_TOKEN
import requests

linode_bp = Blueprint('linode_bp', __name__)

# Initialize Linode client
client = LinodeClient(LINODE_API_TOKEN)

# Endpoint URLs
LINODE_API_BASE_URL = "https://api.linode.com/v4/linode/instances"
LINODE_START_URL = LINODE_API_BASE_URL + "/{linode_id}/boot"
LINODE_STOP_URL = LINODE_API_BASE_URL + "/{linode_id}/shutdown"
LINODE_REBOOT_URL = LINODE_API_BASE_URL + "/{linode_id}/reboot"
LINODE_TERMINATE_URL = LINODE_API_BASE_URL + "/{linode_id}"

# Headers
headers = {
    "Authorization": f"Bearer {LINODE_API_TOKEN}",
    "Content-Type": "application/json"
}

@linode_bp.route('/linode', methods=['GET'])
def linode_manager():
    try:
        linodes = client.linode.instances()
        linode_data = []
        for linode in linodes:
            linode_type = str(linode.type).replace("Type: ", "")
            linode_data.append({
                'LinodeId': linode.id,
                'LinodeType': linode_type,
                'Label': linode.label,
                'Status': linode.status
            })
        return render_template('linode.html', linodes=linode_data)
    except Exception as e:
        print(f"Error fetching Linode instances: {str(e)}")
        return render_template('linode.html', linodes=[])

@linode_bp.route('/linode/launch', methods=['POST'])
def launch_linode():
    linode_name = request.json.get('linode_name', 'MyLinode')
    try:
        linode = client.linode.instance_create(
            'g6-nanode-1',  # Linode Type (nanode instance)
            'us-east',      # Region
            image='linode/debian10',  # Image
            label=linode_name
        )
        return jsonify({'message': 'Linode launch initiated.'}), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@linode_bp.route('/linode/<linode_id>/start', methods=['POST'])
def start_linode(linode_id):
    url = LINODE_START_URL.format(linode_id=linode_id)
    response = requests.post(url, headers=headers)
    return jsonify(response.json()), response.status_code

@linode_bp.route('/linode/<linode_id>/stop', methods=['POST'])
def stop_linode(linode_id):
    url = LINODE_STOP_URL.format(linode_id=linode_id)
    response = requests.post(url, headers=headers)
    return jsonify(response.json()), response.status_code

@linode_bp.route('/linode/<linode_id>/restart', methods=['POST'])
def restart_linode(linode_id):
    url = LINODE_REBOOT_URL.format(linode_id=linode_id)
    response = requests.post(url, headers=headers)
    return jsonify(response.json()), response.status_code

@linode_bp.route('/linode/<linode_id>/terminate', methods=['POST'])
def terminate_linode(linode_id):
    url = LINODE_TERMINATE_URL.format(linode_id=linode_id)
    response = requests.delete(url, headers=headers)
    return jsonify(response.json()), response.status_code

def get_linode_instances():
    try:
        linodes = client.linode.instances()
        linode_data = []
        for linode in linodes:
            linode_type = str(linode.type).replace("Type: ", "")
            linode_data.append({
                'LinodeId': linode.id,
                'LinodeType': linode_type,
                'Label': linode.label,
                'Status': linode.status
            })
        return linode_data
    except Exception as e:
        print(f"Error fetching Linode instances: {str(e)}")
        return []

