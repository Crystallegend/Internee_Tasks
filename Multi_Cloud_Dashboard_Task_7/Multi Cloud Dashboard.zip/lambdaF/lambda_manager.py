import json
from flask import Blueprint, jsonify, request, render_template
import boto3
from botocore.exceptions import ClientError
from config import AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, AWS_REGION

lambda_bp = Blueprint('lambda_bp', __name__)

lambda_client = boto3.client(
    'lambda',
    aws_access_key_id=AWS_ACCESS_KEY_ID,
    aws_secret_access_key=AWS_SECRET_ACCESS_KEY,
    region_name=AWS_REGION
)

@lambda_bp.route('/lambda')
def lambda_manager():
    try:
        response = lambda_client.list_functions()
        functions_data = response['Functions']
        return render_template('lambda.html', functions=functions_data)
    except ClientError as e:
        return render_template('lambda.html', error=str(e))

@lambda_bp.route('/lambda/create', methods=['POST'])
def create_lambda():
    function_name = request.form['functionName']
    role = request.form['role']
    runtime = request.form.get('runtime', 'python3.8')  # Default runtime if not provided
    handler = request.form.get('handler', 'lambda_function.lambda_handler')  # Default handler if not provided

    # Check if the post request has the file part
    if 'code' not in request.files:
        return jsonify({'error': 'No file part in the request'}), 400

    file = request.files['code']

    # If the user does not select a file, browser may also submit an empty part without filename
    if file.filename == '':
        return jsonify({'error': 'No selected file'}), 400

    try:
        # Read the file content
        code = file.read()

        # Create the Lambda function
        lambda_client = boto3.client('lambda')  # Initialize your Lambda client here
        response = lambda_client.create_function(
            FunctionName=function_name,
            Runtime=runtime,
            Role=role,
            Handler=handler,
            Code={
                'ZipFile': code
            },
            Publish=True
        )

        return jsonify({'message': f'Function "{function_name}" created successfully.'}), 200

    except ClientError as e:
        error_message = f"Failed to create Lambda function: {str(e)}"
        print(error_message)
        return jsonify({'error': error_message}), 400

    except Exception as e:
        error_message = f"Unexpected error: {str(e)}"
        print(error_message)
        return jsonify({'error': error_message}), 500


@lambda_bp.route('/lambda/delete', methods=['POST'])
def delete_lambda():
    data = request.get_json()
    function_name = data['functionName']

    try:
        lambda_client.delete_function(FunctionName=function_name)
        return jsonify({'message': f'Function {function_name} deleted successfully.'}), 200
    except ClientError as e:
        return jsonify({'error': str(e)}), 400

@lambda_bp.route('/lambda/invoke', methods=['POST'])
def invoke_lambda():
    data = request.get_json()
    function_name = data['functionName']
    payload = data.get('payload', '{}')

    try:
        response = lambda_client.invoke(
            FunctionName=function_name,
            InvocationType='RequestResponse',
            Payload=json.dumps(payload).encode('utf-8')
        )

        # Read the response body and parse it as JSON
        response_payload = json.loads(response['Payload'].read().decode('utf-8'))
        
        return jsonify(response_payload['body']), 200  # Return the body attribute of the Lambda response
    except ClientError as e:
        return jsonify({'error': str(e)}), 400

def get_lambda_functions():
    try:
        response = lambda_client.list_functions()
        functions_data = response['Functions']
        return functions_data
    except ClientError as e:
        print(f"Failed to list Lambda functions: {str(e)}")
        return []

