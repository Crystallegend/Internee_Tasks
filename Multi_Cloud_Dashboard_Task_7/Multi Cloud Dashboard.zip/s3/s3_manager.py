from flask import Blueprint, jsonify, request, render_template
import boto3
from botocore.exceptions import ClientError
from config import AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, AWS_REGION

s3_bp = Blueprint('s3_bp', __name__)

s3 = boto3.client(
    's3',
    aws_access_key_id=AWS_ACCESS_KEY_ID,
    aws_secret_access_key=AWS_SECRET_ACCESS_KEY,
    region_name=AWS_REGION
)

@s3_bp.route('/s3')
def s3_manager():
    try:
        response = s3.list_buckets()
        bucket_data = [{'Name': bucket['Name']} for bucket in response['Buckets']]
        return render_template('s3.html', buckets=bucket_data)
    except ClientError as e:
        return render_template('s3.html', error=str(e))

@s3_bp.route('/s3/create-bucket', methods=['POST'])
def create_bucket():
    bucket_name = request.json.get('bucket_name')
    try:
        s3.create_bucket(Bucket=bucket_name)
        return jsonify({'message': f'Bucket {bucket_name} created successfully.'}), 200
    except ClientError as e:
        return jsonify({'error': str(e)}), 400

@s3_bp.route('/s3/<bucket_name>/list_objects', methods=['GET'])
def list_objects(bucket_name):
    try:
        response = s3.list_objects_v2(Bucket=bucket_name)
        objects = [{'Key': obj['Key']} for obj in response.get('Contents', [])]
        return jsonify({'objects': objects}), 200
    except ClientError as e:
        return jsonify({'error': str(e)}), 400

@s3_bp.route('/s3/<bucket_name>/delete-object/<object_key>', methods=['DELETE'])
def delete_object(bucket_name, object_key):
    try:
        s3.delete_object(Bucket=bucket_name, Key=object_key)
        return jsonify({'message': f'Successfully deleted object {object_key} from bucket {bucket_name}'}), 200
    except ClientError as e:
        return jsonify({'error': str(e)}), 400

@s3_bp.route('/s3/<bucket_name>/delete', methods=['POST'])
def delete_bucket(bucket_name):
    try:
        s3.delete_bucket(Bucket=bucket_name)
        return jsonify({'message': f'Bucket {bucket_name} deleted successfully.'}), 200
    except ClientError as e:
        return jsonify({'error': str(e)}), 400

@s3_bp.route('/s3/<bucket_name>/upload', methods=['POST'])
def upload_file(bucket_name):
    try:
        file = request.files['file']
        s3.upload_fileobj(file, bucket_name, file.filename)
        return jsonify({'message': f'File {file.filename} uploaded successfully.'}), 200
    except ClientError as e:
        return jsonify({'error': str(e)}), 400

@s3_bp.route('/s3/<bucket_name>/delete-with-contents', methods=['POST'])
def delete_bucket_with_contents(bucket_name):
    try:
        # First, list objects in the bucket
        response = s3.list_objects_v2(Bucket=bucket_name)
        objects = [{'Key': obj['Key']} for obj in response.get('Contents', [])]

        if objects:
            # If there are objects, delete them first
            for obj in objects:
                s3.delete_object(Bucket=bucket_name, Key=obj['Key'])

        # Then delete the bucket
        s3.delete_bucket(Bucket=bucket_name)

        return jsonify({'message': f'Bucket {bucket_name} deleted successfully.'}), 200
    except ClientError as e:
        return jsonify({'error': str(e)}), 400

def get_s3_buckets():
    try:
        response = s3.list_buckets()
        bucket_data = [{'Name': bucket['Name'], 'CreationDate': bucket['CreationDate']} for bucket in response['Buckets']]
        return bucket_data
    except ClientError as e:
        print(f"Failed to list S3 buckets: {str(e)}")
        return []
