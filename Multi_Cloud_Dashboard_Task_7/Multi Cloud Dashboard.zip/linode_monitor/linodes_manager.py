from flask import Blueprint, render_template
from linode.linode_manager import get_linode_instances
from storage.storage_manager import get_storage_instances

linodes_bp = Blueprint('linodes_bp', __name__)

@linodes_bp.route('/linode_monitor')
def linode_monitor():
    # Fetch EC2 instances data
    linode_instances = get_linode_instances()
    
    # Fetch S3 buckets data
    storage_buckets = get_storage_instances()
    

    # Render the aws_monitor.html template with the fetched data
    return render_template('linode_monitor.html', linode_instances=linode_instances, storage_buckets=storage_buckets)
