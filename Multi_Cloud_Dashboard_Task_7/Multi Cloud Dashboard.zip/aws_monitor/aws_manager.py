from flask import Blueprint, render_template
from ec2.ec2_manager import get_ec2_instances
from s3.s3_manager import get_s3_buckets
from lambdaF.lambda_manager import get_lambda_functions

aws_bp = Blueprint('aws_bp', __name__)

@aws_bp.route('/aws_monitor')
def aws_monitor():
    # Fetch EC2 instances data
    ec2_instances = get_ec2_instances()
    
    # Fetch S3 buckets data
    s3_buckets = get_s3_buckets()
    
    # Fetch Lambda functions data
    lambda_functions = get_lambda_functions()
    
    # Render the aws_monitor.html template with the fetched data
    return render_template('aws_monitor.html', ec2_instances=ec2_instances, s3_buckets=s3_buckets, lambda_functions=lambda_functions)
