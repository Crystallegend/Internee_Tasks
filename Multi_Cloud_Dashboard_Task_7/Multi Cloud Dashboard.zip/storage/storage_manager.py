from flask import Blueprint, jsonify, request, render_template
import requests
from config import LINODE_API_TOKEN

storage_bp = Blueprint('storage_bp', __name__)

HEADERS = {
    'Authorization': f'Bearer {LINODE_API_TOKEN}',
    'Content-Type': 'application/json',
    'accept': 'application/json'
}

@storage_bp.route('/storage')
def storage_manager():
    url = "https://api.linode.com/v4/object-storage/buckets"
    response = requests.get(url, headers=HEADERS)
    
    if response.status_code == 200:
        buckets = response.json().get('data', [])
        bucket_data = [{'Name': bucket['label'], 'Region': bucket['cluster']} for bucket in buckets]
        return render_template('storage.html', buckets=bucket_data)
    else:
        return render_template('storage.html', error=response.json().get('error', 'Error listing buckets'))

@storage_bp.route('/storage/create', methods=['POST'])
def create_bucket():
    data = request.get_json()
    bucket_name = data.get('bucket_name')
    region = data.get('region')

    if not bucket_name or not region:
        return jsonify({'message': 'Bucket name and region are required'}), 400

    payload = {
        'label': bucket_name,
        'cluster': region,
        'acl': 'private',
        'cors_enabled': True
    }

    url = "https://api.linode.com/v4/object-storage/buckets"
    response = requests.post(url, json=payload, headers=HEADERS)

    if response.status_code == 200 or response.status_code == 201:
        return jsonify({'message': f'Bucket {bucket_name} created successfully.'}), 201
    else:
        return jsonify({'error': response.text}), response.status_code

@storage_bp.route('/storage/<region>/<bucket_name>/contents', methods=['GET'])
def get_bucket_contents(region, bucket_name):
    url = f"https://api.linode.com/v4/object-storage/buckets/{region}/{bucket_name}/object-list?page_size=100"
    response = requests.get(url, headers=HEADERS)

    if response.status_code == 200:
        contents = response.json().get('data', [])
        return jsonify({'contents': contents}), 200
    else:
        return jsonify({'error': response.json().get('error', 'Error getting bucket contents')}), response.status_code

@storage_bp.route('/storage/<region>/<bucket_name>/delete', methods=['POST'])
def delete_bucket(region, bucket_name):
    url = f"https://api.linode.com/v4/object-storage/buckets/{region}/{bucket_name}"
    response = requests.delete(url, headers=HEADERS)

    if response.status_code == 200 or response.status_code == 204:
        return jsonify({'message': f'Bucket {bucket_name} deleted successfully.'}), 200
    else:
        return jsonify({'message': response.json().get("errors")[0]["reason"]}), response.status_code

def get_storage_instances():
    url = "https://api.linode.com/v4/object-storage/buckets"
    response = requests.get(url, headers=HEADERS)
    
    if response.status_code == 200:
        buckets = response.json().get('data', [])
        bucket_data = [{'Name': bucket['label'], 'Region': bucket['cluster']} for bucket in buckets]
        return bucket_data
    else:
        return []
