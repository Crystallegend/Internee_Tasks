import boto3
import requests
from config import aws_access_key, aws_secret_key, region

# Function to initialize AWS clients
def initialize_clients(aws_access_key, aws_secret_key, region):
    session = boto3.Session(
        aws_access_key_id=aws_access_key,
        aws_secret_access_key=aws_secret_key,
        region_name=region
    )
    mgn_client = session.client('mgn')
    ec2_client = session.client('ec2')
    return mgn_client, ec2_client

# Function to describe the source servers
def describe_source_servers(mgn_client):
    response = mgn_client.describe_source_servers()
    source_servers = response['items']
    filtered_servers = [server for server in source_servers if server['dataReplicationInfo']['dataReplicationState'] not in ['DISCONNECTED','DISCOVERED','PENDING_INSTALLATION','DISCONNECTED']]
    return filtered_servers

# Function to launch a test instance
def launch_test_instance(mgn_client, source_server_id):
    response = mgn_client.start_test(
        sourceServerIDs=[source_server_id]
    )
    return response['job']['participatingServers'][0]['launchStatus']

# Function to launch a cutover instance
def launch_cutover_instance(mgn_client, source_server_id):
    response = mgn_client.start_cutover(
        sourceServerIDs=[source_server_id]
    )
    return response['job']['participatingServers'][0]['launchStatus']

# Function to get the public IP of an EC2 instance
def get_instance_public_ip(ec2_client, instance_id):
    response = ec2_client.describe_instances(InstanceIds=[instance_id])
    reservations = response['Reservations']
    if reservations and 'PublicIpAddress' in reservations[0]['Instances'][0]:
        return reservations[0]['Instances'][0]['PublicIpAddress']
    return None

# # Function to finalize the testing
def finalize_testing(source_server_id, mgn_client):
    response = mgn_client.change_server_life_cycle_state(
        lifeCycle={
            'state': 'READY_FOR_CUTOVER'
        },
        sourceServerID=source_server_id
    )
    return True

# Function to finalize the cutover
def finalize_cutover(source_server_id, mgn_client):
    response = mgn_client.finalize_cutover(
            sourceServerID=source_server_id
        )
    return True

def describe_server_job(mgn_client):
    response = mgn_client.describe_jobs()
    return response['items']

# Main function
def main():
    mgn_client, ec2_client = initialize_clients(aws_access_key, aws_secret_key, region)
    
    source_servers = describe_source_servers(mgn_client)
    if not source_servers:
        print("No suitable source servers found.")
        return
    
    source_server = source_servers[0]
    source_server_id = source_server['sourceServerID']
    lifecycle_state = source_server['lifeCycle']['state']

    if lifecycle_state == 'READY_FOR_TEST':
        launch_test = input("The source server is ready for testing. Do you want to launch a test instance? (yes/no): ").strip().lower()
        if launch_test != 'yes':
            print("Exiting without launching a test instance.")
            return
        instance_status = launch_test_instance(mgn_client, source_server_id)
        print(f'Launch Initiated. EC2 Status: {instance_status}')
        return

    elif lifecycle_state == "TESTING" or lifecycle_state == "CUTTING_OVER":
        print(f"Current Source Server Status is '{lifecycle_state}'")
        describe_job = describe_server_job(mgn_client)
        instance_status = describe_job[0]['participatingServers'][0]['launchStatus']
        if instance_status != "LAUNCHED":
            print(f'EC2 Instance Status: {instance_status}. Please wait for the instance to be launched')
            return
        else:
            instance_id = describe_job[0]["participatingServers"][0][ 'launchedEc2InstanceID']
        
    elif lifecycle_state == 'READY_FOR_CUTOVER':
        launch_cutover = input("The source server is ready for cutover. Do you want to launch a cutover instance? (yes/no): ").strip().lower()
        if launch_cutover != 'yes':
            print("Exiting without launching a cutover instance.")
            return
        instance_status = launch_cutover_instance(mgn_client, source_server_id)
        print(f'Launch Initiated. EC2 Status: {instance_status}')
        return
    else:
        print("The source server is not ready for testing or cutover.")
        return
    
    public_ip = get_instance_public_ip(ec2_client, instance_id)
    if public_ip:
        print(f"Instance public IP: {public_ip}")
    else:
        print(f"Instance link: https://{region}.console.aws.amazon.com/ec2/v2/home?region={region}#Instances:instanceId={instance_id}")
    
    input("Press Enter once you have checked the server: ")
    
    if lifecycle_state == 'TESTING':
        if finalize_testing(source_server_id, mgn_client):
            print("Testing finalized successfully")
        else:
            print("Failed to finalize testing")
    elif lifecycle_state == 'CUTTING_OVER':
        if finalize_cutover(source_server_id, mgn_client):
            print("Cutover finalized successfully.")
        else:
            print("Failed to finalize cutover.")

if __name__ == "__main__":
    main()
