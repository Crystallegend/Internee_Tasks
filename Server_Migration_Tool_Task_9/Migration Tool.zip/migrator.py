import boto3
import paramiko
from config import local_server_ip, source_username, pem_file_location, aws_access_key, aws_secret_key, region

key = paramiko.RSAKey.from_private_key_file(pem_file_location)
ssh = paramiko.SSHClient()
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
ssh.connect(local_server_ip, username=source_username, pkey=key)

commands = [
    f"sudo wget -O ./aws-replication-installer-init https://aws-application-migration-service-{region}.s3.{region}.amazonaws.com/latest/linux/aws-replication-installer-init",
    f"sudo chmod +x aws-replication-installer-init; sudo ./aws-replication-installer-init --region {region} --aws-access-key-id {aws_access_key} --aws-secret-access-key {aws_secret_key} --no-prompt"
]

for command in commands:
    stdin, stdout, stderr = ssh.exec_command(command)
    print(stdout.read().decode())
    print(stderr.read().decode())

ssh.close()

